/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centrodeemergenciamain;

import java.util.Objects;

/**
 *
 * @author Sebastian
 */
public abstract class Incidente {

    protected String codigo;
    protected String zona;
    protected NivelPrioridad nivelPrioridad;
    

    public Incidente(String codigo, String zona, NivelPrioridad nivelPrioridad) {
        validarString(zona, "zona Incorrecta");
        validarString(codigo, "codigo Incorrecto");
        validarNivel(nivelPrioridad);
        this.codigo = codigo;
        this.zona = zona;
        this.nivelPrioridad = nivelPrioridad;
    }

    /**
     * metodo privada que un String no sea nulo o este vacio.
     *
     * @param string - a validar
     * @param mensaje - mensaje en caso de error.
     */
    private void validarString(String string, String mensaje) {
        if (string == null || string.isEmpty()) {
            throw new IllegalArgumentException(mensaje);
        }
    }

    /**
     * metodo privado encargado de validar que el NivelSecreto no sea nulo
     *
     * @param nivel Nivel a validar
     * @throws IllegalArgumentException
     */
    private void validarNivel(NivelPrioridad nivel) {
        if (nivel == null) {
            throw new IllegalArgumentException("El nivel de Prioridad no puede ser nulo");
        }
    }

    /**
     * metodo publico que devuelve el codigo del Incidente
     *
     * @return codigo
     */
    public String getCodigo() {
       
        return codigo;

    }
    
        /**
     * metodo publico que devuelve la zona
     * @return AgenteResponsable
     */
    public String getZona(){
        
        return zona;
    }

    
        /**
     * metodo publico que devuelve nivelde Prioridad
     * @return 
     */
    public NivelPrioridad getPrioridad(){
       
        return nivelPrioridad;
    }
    
    @Override
    public String toString() {
        return "Incidente" + "codigo=" + codigo + ", zona=" + zona + ", nivelPrioridad=" + nivelPrioridad;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + Objects.hashCode(this.codigo);
        hash = 83 * hash + Objects.hashCode(this.zona);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Incidente other = (Incidente) obj;
        if (!Objects.equals(this.codigo, other.codigo)) {
            return false;
        }
        return Objects.equals(this.zona, other.zona);
    }

}
