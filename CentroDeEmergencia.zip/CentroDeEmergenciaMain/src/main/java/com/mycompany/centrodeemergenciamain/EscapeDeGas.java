/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centrodeemergenciamain;

/**
 *
 * @author Sebastian
 */
public class EscapeDeGas extends Incidente implements Reparable, Evacuable{

    private int edificiosAfectados;
    private double concentracionDetectada;

    public EscapeDeGas(String codigo, String zona, NivelPrioridad nivelPrioridad, int edificiosAfectados, double concentracionDetectada) {
        super(codigo, zona, nivelPrioridad);
        validarEdificios(edificiosAfectados);
        validarConcentracion(concentracionDetectada);
        this.edificiosAfectados = edificiosAfectados;
        this.concentracionDetectada = concentracionDetectada; 
         
    
    }
    
    private void validarEdificios (Integer edificiosAfectados){
        if (edificiosAfectados == null || edificiosAfectados < 0){
            throw new IllegalArgumentException("Los edificios afectados no pueden ser null o menor a cero");
        }
            
    }
    
    private void validarConcentracion(double concentracion){
        if (concentracion < 0){
            throw new IllegalArgumentException("La concentracion detectada no puede ser menor a cero");
        }
    }
    
    @Override
    public void repararIncidentes() {
         System.out.println("Se inicio la reparacion del incidente " + getCodigo() + " en " + getZona() + " Edificios afectados: " + edificiosAfectados);
    }

    @Override
    public void  ordenarEvacuaciones() {
        System.out.println("Se ordeno la evacuacion por escape de gas " + getCodigo() + " en " + getZona() + ". Concentracion detectada: " + concentracionDetectada+ "%.");
    }

    @Override
    public String toString() {
        return super.toString() + "Edificios afectados " + edificiosAfectados + "Concentracion detectada: " + concentracionDetectada + "%";
    }


    
}
