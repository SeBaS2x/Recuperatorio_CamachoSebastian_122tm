/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centrodeemergenciamain;

/**
 *
 * @author Sebastian
 */
public class IncidenteDuplicadoException extends Exception{
    
    public IncidenteDuplicadoException(String mensaje){
        super(mensaje);
    }
    
}
