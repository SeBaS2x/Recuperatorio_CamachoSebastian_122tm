/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centrodeemergenciamain;

/**
 *
 * @author Sebastian
 */
public class FallaElectrica extends Incidente implements Reparable {

    private int edificiosAfectados;
    private double potenciaKilovatios;

    public FallaElectrica(String codigo, String zona, NivelPrioridad nivelPrioridad, int edificiosAfectados, double potenciaKilovatios) {

        super(codigo, zona, nivelPrioridad);
        validarEdificios(edificiosAfectados);
        validarPotencia(potenciaKilovatios);
        this.edificiosAfectados = edificiosAfectados;
        this.potenciaKilovatios = potenciaKilovatios;
    }

    private void validarEdificios(Integer edificiosAfetados) {
        if (edificiosAfetados == null || edificiosAfetados < 0) {
            throw new IllegalArgumentException("No se admite valores nulos o menores a 0");
        }

    }

    private void validarPotencia(double potenciaKilovatios) {
        if (potenciaKilovatios < 0) {
            throw new IllegalArgumentException("Potencia en kiloVoltios no puede ser menor a 0");
        }
    }

    public int getEdificiosAfectados() {

        return edificiosAfectados;
    }

    @Override
    public String toString() {
        return super.toString() + "Edificios Afectados " + edificiosAfectados + "Potencia " + potenciaKilovatios + "KV.";
    }

    @Override
    public void repararIncidentes() {
        System.out.println("Se inicio la reparacion del incidente " + getCodigo() + " en " + getZona() + " Edificios afectados: " + edificiosAfectados);
    }

}
