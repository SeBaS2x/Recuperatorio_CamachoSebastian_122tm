/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centrodeemergenciamain;

/**
 *
 * @author Sebastian
 */
public class AlertaMeteorologica  extends Incidente implements Evacuable{
    
    private String fenomenoObservado;

    public AlertaMeteorologica(String codigo, String zona, NivelPrioridad nivelPrioridad, String fenomenoObservado) {
        super(codigo, zona, nivelPrioridad);
        validarFenomeno(fenomenoObservado);
        this.fenomenoObservado = fenomenoObservado;
    }

    
    private void validarFenomeno (String fenomeno){
        if (fenomeno == null || fenomeno.isEmpty()){
            throw new IllegalArgumentException("El fenomeno Observado no puede ser null o estar vacio.");
        }
    }
    
    @Override
    public void ordenarEvacuaciones() {
         System.out.println("Se ordeno la evacuacion por alerta meteorologica " + getCodigo() + " en " + getZona() + ". Fenomeno: " + fenomenoObservado);
    }

    @Override
    public String toString() {
        return super.toString() + "Fenomeno Observado: " + fenomenoObservado;
    }
    
    
    
    
}
