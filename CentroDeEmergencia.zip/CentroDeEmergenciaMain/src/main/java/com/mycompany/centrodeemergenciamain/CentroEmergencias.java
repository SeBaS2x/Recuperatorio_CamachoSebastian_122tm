/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.centrodeemergenciamain;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sebastian
 */
public class CentroEmergencias {

    private String nombre;
    private ArrayList<Incidente> incidentes;

    public CentroEmergencias(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        incidentes = new ArrayList<>();
    }

    private void validarNombre (String nombre){
        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede ser nulo o estar vacio");
        }
    }
    /**
     *
     * @return retorna el nombre del arrayList
     */
    public String getNombre() {
        return nombre;
    }
    
    private boolean IncidenteRepetido(Incidente incidente) {
        for (Incidente in : incidentes) {
            if (in.equals(incidente)) {
                return true;
            }
        }
        return false;
    }
    
    public void agregarIncidente(Incidente incidente) throws IncidenteDuplicadoException {
        if (incidente == null) {
            throw new IncidenteDuplicadoException("Ingreso de un nulo");
        }
        if (IncidenteRepetido(incidente)) {
            throw new IncidenteDuplicadoException("Ya existe un expediente con codigo '" + incidente.getCodigo() + "en la zona: " + incidente.getZona());
        }
        incidentes.add(incidente);
    }

    public List<Incidente> obtenerIncidentes() {
        return incidentes;
    }

    public List<Incidente> filtrarPorPrioridad(NivelPrioridad prioridad) {

        List<Incidente> lista = new ArrayList<>();

        for (Incidente i : incidentes) {

            if (i.getPrioridad() == prioridad) {
                lista.add(i);
            }
        }

        return lista;
    }
}


